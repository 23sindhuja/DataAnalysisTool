from tkinter import *
from tkinter import filedialog, messagebox
from data_analyzer import analyze_data, create_chart
from report_generator import generate_html

def upload_file():
    file_path = filedialog.askopenfilename(
        filetypes=[("CSV Files", "*.csv")]
    )

    if file_path:
        df, summary, missing = analyze_data(file_path)
        generate_html(summary, missing)
        create_chart(df)
        messagebox.showinfo("Success", "HTML Report Generated Successfully!")

root = Tk()
root.title("Data Analysis Tool")
root.geometry("350x200")

Label(root, text="Desktop Data Analysis Tool", font=("Arial", 12)).pack(pady=20)
Button(root, text="Upload CSV File", command=upload_file).pack()

root.mainloop()
