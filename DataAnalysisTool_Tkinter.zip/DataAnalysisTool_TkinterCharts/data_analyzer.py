import pandas as pd
import matplotlib.pyplot as plt

def analyze_data(file_path):
    df = pd.read_csv(file_path)

    summary = df.describe(include='all')
    missing_values = df.isnull().sum()

    return df, summary, missing_values

def create_chart(df):
    df.groupby("Department")["Salary"].mean().plot(kind="bar")
    plt.title("Average Salary by Department")
    plt.xlabel("Department")
    plt.ylabel("Average Salary")
    plt.tight_layout()
    plt.show()
