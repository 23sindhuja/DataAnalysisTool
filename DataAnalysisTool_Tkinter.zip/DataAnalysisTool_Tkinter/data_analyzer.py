import pandas as pd

def analyze_data(file_path):
    # Read CSV file
    df = pd.read_csv(file_path)

    # Basic analysis
    summary = df.describe(include='all')
    missing_values = df.isnull().sum()

    return df, summary, missing_values
