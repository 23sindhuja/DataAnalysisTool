def generate_html(summary, missing):
    html_content = f"""
    <html>
    <head>
        <link rel="stylesheet" href="style.css">
        <title>Data Analysis Report</title>
    </head>
    <body>
        <h1>Data Analysis Report</h1>

        <h2>Summary Statistics</h2>
        {summary.to_html()}

        <h2>Missing Values</h2>
        {missing.to_frame("Missing Count").to_html()}
    </body>
    </html>
    """

    with open("reports/report.html", "w") as file:
        file.write(html_content)
