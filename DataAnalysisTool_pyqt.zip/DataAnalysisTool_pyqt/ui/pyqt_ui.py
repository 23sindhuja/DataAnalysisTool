import sys
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(BASE_DIR)

from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import (
    QApplication, QWidget, QPushButton,
    QLabel, QFileDialog, QMessageBox, QVBoxLayout
)

from data_analyzer import analyze_data, create_chart
from report_generator import generate_html


class DataAnalysisApp(QWidget):
    def __init__(self):
        super().__init__()
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("Data Analysis Tool (PyQt5)")
        self.setGeometry(100, 100, 400, 200)

        layout = QVBoxLayout()

        title = QLabel("Desktop Data Analysis Tool")
        title.setStyleSheet("font-size:16px; font-weight:bold;")
        title.setAlignment(Qt.AlignCenter)

        self.button = QPushButton("Upload CSV File")
        self.button.clicked.connect(self.open_file)

        layout.addWidget(title)
        layout.addWidget(self.button)

        self.setLayout(layout)

    def open_file(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Select CSV File",
            "",
            "CSV Files (*.csv)"
        )

        if file_path:
            df, summary, missing = analyze_data(file_path)
            generate_html(summary, missing)
            create_chart(df)

            QMessageBox.information(
                self,
                "Success",
                "HTML Report & Chart Generated Successfully!"
            )


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = DataAnalysisApp()
    window.show()
    sys.exit(app.exec_())
