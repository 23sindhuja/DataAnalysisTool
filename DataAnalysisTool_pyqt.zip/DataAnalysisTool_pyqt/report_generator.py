import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
REPORT_DIR = os.path.join(BASE_DIR, "reports")

def generate_html(summary, missing):
    os.makedirs(REPORT_DIR, exist_ok=True)

    html_content = f"""
    <html>
    <head>
        <link rel="stylesheet" href="style.css">
        <title>Data Analysis Report</title>
    </head>
    <body>
        <h1>Data Analysis Report</h1>

        <h2>Summary Statistics</h2>
        {summary.to_html()}

        <h2>Missing Values</h2>
        {missing.to_frame("Missing Count").to_html()}
    </body>
    </html>
    """

    report_path = os.path.join(REPORT_DIR, "report.html")

    with open(report_path, "w", encoding="utf-8") as file:
        file.write(html_content)
